package com.eusa.miapinasa

import android.os.Bundle
import android.widget.TextView
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var titleTextView: TextView
    private lateinit var dateTextView: TextView
    private lateinit var explanationTextView: TextView
    private lateinit var apodImageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        titleTextView = findViewById(R.id.titleTextView)
        dateTextView = findViewById(R.id.dateTextView)
        explanationTextView = findViewById(R.id.explanationTextView)
        apodImageView = findViewById(R.id.apodImageView)

        fetchApodData()
    }

    private fun fetchApodData() {
        thread {
            val client = NasaApodClient()
            try {
                val apodData = client.getApodData()
                displayApodData(apodData)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun displayApodData(apodData: JSONObject) {
        val title = apodData.getString("title")
        val date = apodData.getString("date")
        val explanation = apodData.getString("explanation")
        val imageUrl = apodData.getString("url")

        runOnUiThread {
            titleTextView.text = title
            dateTextView.text = date
            explanationTextView.text = explanation
            Glide.with(this).load(imageUrl).into(apodImageView)
        }
    }
}

package com.eusa.miapinasa;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

public class NasaApodClient {
    private static final String NASA_APOD_API_URL = "https://api.nasa.gov/planetary/apod";
    private static final String API_KEY = "C1mENnDgQWNLMDQj9utwJPYMb8CNlQMd8YEY1zfV";

    public JSONObject getApodData() throws IOException, JSONException {
        String randomDate = getRandomDate();
        String urlWithParams = NASA_APOD_API_URL + "?api_key=" + API_KEY + "&date=" + randomDate;

        URL url = new URL(urlWithParams);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
            throw new IOException("Error en la solicitud: " + conn.getResponseCode());
        }

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String inputLine;

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        return new JSONObject(response.toString());
    }

    private String getRandomDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, -10); // Hace 10 años desde el año actual

        int startYear = calendar.get(Calendar.YEAR);
        int endYear = Calendar.getInstance().get(Calendar.YEAR);
        Random random = new Random();

        int randomYear = random.nextInt(endYear - startYear + 1) + startYear;
        int randomMonth = random.nextInt(12) + 1;
        int randomDay = random.nextInt(28) + 1;

        calendar.set(randomYear, randomMonth - 1, randomDay);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(calendar.getTime());
    }

    public JSONObject getMarsRoverPhotos(String rover, String date) throws IOException, JSONException {
        String urlWithParams = "https://api.nasa.gov/mars-photos/api/v1/rovers/" + rover + "/photos?earth_date=" + date + "&api_key=" + API_KEY;
        URL url = new URL(urlWithParams);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
            throw new IOException("Error en la solicitud: " + conn.getResponseCode());
        }

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String inputLine;

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        return new JSONObject(response.toString());
    }
}
